declare const classNames: {
  readonly "checkbox-container": "checkbox-container";
};
export = classNames;
