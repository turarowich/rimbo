declare const classNames: {
  readonly progress: "progress";
  readonly item: "item";
};
export = classNames;
