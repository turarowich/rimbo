declare const classNames: {
  readonly pagination: "pagination";
  readonly button: "button";
  readonly "button-active": "button-active";
  readonly "button-disabled": "button-disabled";
};
export = classNames;
