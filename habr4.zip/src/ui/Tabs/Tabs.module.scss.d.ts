declare const classNames: {
  readonly tabs: "tabs";
  readonly "tabs-tab": "tabs-tab";
  readonly "tabs-tab-active": "tabs-tab-active";
};
export = classNames;
