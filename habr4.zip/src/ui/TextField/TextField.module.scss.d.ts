declare const classNames: {
  readonly "text-field": "text-field";
};
export = classNames;
