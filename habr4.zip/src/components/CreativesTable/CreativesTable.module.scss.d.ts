declare const classNames: {
  readonly "creatives-table": "creatives-table";
  readonly button: "button";
  readonly "button-columns-active": "button-columns-active";
  readonly "columns-dropdown": "columns-dropdown";
};
export = classNames;
