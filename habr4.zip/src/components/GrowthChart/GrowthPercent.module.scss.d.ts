declare const classNames: {
  readonly 'growth-chart': 'growth-chart'
  readonly positive: 'positive'
  readonly arrow: 'arrow'
  readonly negative: 'negative'
}
export = classNames
