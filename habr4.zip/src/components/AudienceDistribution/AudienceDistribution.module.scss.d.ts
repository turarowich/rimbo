declare const classNames: {
  readonly "audience-distribution": "audience-distribution";
  readonly box: "box";
  readonly content: "content";
  readonly list: "list";
  readonly "list-item": "list-item";
  readonly "legend-list": "legend-list";
  readonly "legend-list-item": "legend-list-item";
  readonly "legend-list-circle": "legend-list-circle";
};
export = classNames;
