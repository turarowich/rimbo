declare const classNames: {
  readonly "top-cities-distribution": "top-cities-distribution";
  readonly box: "box";
  readonly list: "list";
  readonly "list-item": "list-item";
};
export = classNames;
