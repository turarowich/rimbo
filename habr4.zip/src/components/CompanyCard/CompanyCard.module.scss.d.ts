declare const classNames: {
  readonly "company-card": "company-card";
  readonly active: "active";
  readonly stats: "stats";
  readonly "stats-item": "stats-item";
};
export = classNames;
