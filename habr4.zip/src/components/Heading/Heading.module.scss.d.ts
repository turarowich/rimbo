declare const classNames: {
  readonly heading: "heading";
};
export = classNames;
