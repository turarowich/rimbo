declare const classNames: {
  readonly "advertisement-chart": "advertisement-chart";
};
export = classNames;
