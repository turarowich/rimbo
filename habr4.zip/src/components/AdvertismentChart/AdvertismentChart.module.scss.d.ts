declare const classNames: {
  readonly "advertisment-chart": "advertisment-chart";
  readonly box: "box";
  readonly wrapper: "wrapper";
  readonly chart: "chart";
  readonly "chart-labels": "chart-labels";
  readonly "scroll-container": "scroll-container";
};
export = classNames;
