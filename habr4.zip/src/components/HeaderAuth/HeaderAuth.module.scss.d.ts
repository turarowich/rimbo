declare const classNames: {
  readonly header: "header";
};
export = classNames;
