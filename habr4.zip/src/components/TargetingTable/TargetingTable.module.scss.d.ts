declare const classNames: {
  readonly "targeting-table": "targeting-table";
};
export = classNames;
