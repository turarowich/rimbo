declare const classNames: {
  readonly "advertisement-type": "advertisement-type";
  readonly box: "box";
  readonly top: "top";
  readonly "top-circle": "top-circle";
};
export = classNames;
