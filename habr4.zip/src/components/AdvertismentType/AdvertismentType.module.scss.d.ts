declare const classNames: {
  readonly "advertisment-type": "advertisment-type";
  readonly box: "box";
  readonly top: "top";
  readonly "top-circle": "top-circle";
};
export = classNames;
