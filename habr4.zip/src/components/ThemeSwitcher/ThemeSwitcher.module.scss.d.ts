declare const classNames: {
  readonly "theme-switcher": "theme-switcher";
  readonly "full-width": "full-width";
  readonly track: "track";
  readonly right: "right";
  readonly theme: "theme";
};
export = classNames;
