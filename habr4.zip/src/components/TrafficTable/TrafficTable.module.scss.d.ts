declare const classNames: {
  readonly "traffic-table": "traffic-table";
  readonly box: "box";
  readonly wrapper: "wrapper";
  readonly "top-line": "top-line";
  readonly "top-line-right": "top-line-right";
  readonly button: "button";
  readonly right: "right";
  readonly "button-columns-active": "button-columns-active";
  readonly "columns-dropdown": "columns-dropdown";
  readonly "table-container": "table-container";
  readonly table: "table";
};
export = classNames;
