declare const classNames: {
  readonly box: "box";
};
export = classNames;
