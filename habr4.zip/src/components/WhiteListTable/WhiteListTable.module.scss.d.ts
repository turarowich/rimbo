declare const classNames: {
  readonly "white-list-table": "white-list-table";
  readonly list: "list";
  readonly row: "row";
};
export = classNames;
