declare const classNames: {
  readonly "companies-carousel-container": "companies-carousel-container";
  readonly "prev-btn": "prev-btn";
  readonly "next-btn": "next-btn";
  readonly "companies-carousel": "companies-carousel";
  readonly "swiper-slide": "swiper-slide";
};
export = classNames;
