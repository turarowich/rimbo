declare const classNames: {
  readonly "bar-chart": "bar-chart";
  readonly box: "box";
  readonly wrapper: "wrapper";
  readonly "values-list": "values-list";
  readonly "values-list-item": "values-list-item";
  readonly "values-list-circle": "values-list-circle";
  readonly chart: "chart";
};
export = classNames;
