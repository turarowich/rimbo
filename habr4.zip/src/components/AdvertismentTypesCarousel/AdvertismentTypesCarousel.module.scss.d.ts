declare const classNames: {
  readonly "advertisment-types-carousel": "advertisment-types-carousel";
  readonly "prev-btn": "prev-btn";
  readonly "next-btn": "next-btn";
  readonly carousel: "carousel";
  readonly "swiper-slide": "swiper-slide";
};
export = classNames;
