declare const classNames: {
  readonly "placement-table": "placement-table";
  readonly list: "list";
  readonly row: "row";
};
export = classNames;
