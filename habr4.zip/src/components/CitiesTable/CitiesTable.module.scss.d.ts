declare const classNames: {
  readonly "cities-table": "cities-table";
};
export = classNames;
