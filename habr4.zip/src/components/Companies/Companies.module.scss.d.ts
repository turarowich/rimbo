declare const classNames: {
  readonly companies: "companies";
  readonly wrapper: "wrapper";
  readonly background: "background";
  readonly light: "light";
  readonly "total-row": "total-row";
  readonly list: "list";
  readonly item: "item";
  readonly "item-arrow": "item-arrow";
  readonly "new-company-button": "new-company-button";
};
export = classNames;
