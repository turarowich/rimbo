declare const classNames: {
  readonly "lang-switcher": "lang-switcher";
  readonly icon: "icon";
  readonly lang: "lang";
  readonly arrow: "arrow";
};
export = classNames;
