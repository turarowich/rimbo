declare const classNames: {
  readonly "devices-distribution": "devices-distribution";
  readonly box: "box";
  readonly content: "content";
  readonly legend: "legend";
  readonly chart: "chart";
  readonly "legend-row": "legend-row";
  readonly "legend-row-circle": "legend-row-circle";
  readonly "legend-row-label": "legend-row-label";
};
export = classNames;
