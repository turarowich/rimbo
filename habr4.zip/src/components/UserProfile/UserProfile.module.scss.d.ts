declare const classNames: {
  readonly "user-profile": "user-profile";
  readonly notifications: "notifications";
  readonly "notifications-count": "notifications-count";
  readonly "dropdown-button": "dropdown-button";
  readonly active: "active";
  readonly "arrow-down": "arrow-down";
  readonly avatar: "avatar";
  readonly "dropdown-menu": "dropdown-menu";
  readonly "menu-item": "menu-item";
};
export = classNames;
