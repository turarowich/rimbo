declare const classNames: {
  readonly "companies-tables": "companies-tables";
  readonly box: "box";
  readonly wrapper: "wrapper";
  readonly "top-line": "top-line";
  readonly content: "content";
  readonly button: "button";
};
export = classNames;
