declare const classNames: {
  readonly logo: "logo";
};
export = classNames;
