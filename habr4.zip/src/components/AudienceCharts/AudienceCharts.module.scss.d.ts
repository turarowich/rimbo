declare const classNames: {
  readonly "audience-charts": "audience-charts";
  readonly wrapper: "wrapper";
  readonly "charts-list": "charts-list";
};
export = classNames;
