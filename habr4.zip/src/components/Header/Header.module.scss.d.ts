declare const classNames: {
  readonly header: "header";
  readonly wrapper: "wrapper";
  readonly right: "right";
  readonly nav: "nav";
  readonly "mobile-menu-button": "mobile-menu-button";
  readonly "header-fixed": "header-fixed";
  readonly active: "active";
  readonly "mobile-menu": "mobile-menu";
  readonly "mobile-menu-open": "mobile-menu-open";
  readonly profile: "profile";
  readonly avatar: "avatar";
  readonly notifications: "notifications";
  readonly "profile-right": "profile-right";
  readonly "nav-mobile": "nav-mobile";
  readonly "theme-switcher-container": "theme-switcher-container";
};
export = classNames;
